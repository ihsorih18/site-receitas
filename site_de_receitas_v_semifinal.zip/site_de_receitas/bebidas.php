<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receitas de Bebidas</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #FA9854, #FAB95C);
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #FA622D;
            margin-bottom: 30px;
        }
        .bebidas-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }
        .bebida-card {
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .bebida-card:hover {
            transform: translateY(-5px);
        }
        .bebida-card img {
            
            height: 200px; /* Altura fixa */
            object-fit: cover; /* Mantém a proporção, centralizando */
        }
        .bebida-content {
            padding: 15px;
        }
        .bebida-title {
            font-size: 18px;
            margin-bottom: 10px;
            color: #333;
            text-align: center;
        }
        .bebida-description {
            font-size: 14px;
            color: #333;
            text-align: justify;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Receitas de Bebidas</h1>
        <div class="bebidas-grid">
            <?php
            // Conexão com o banco de dados
            $host = "localhost";
            $user = "root";
            $password = "";
            $database = "site_receitas";

            $conn = new mysqli($host, $user, $password, $database);

            if ($conn->connect_error) {
                die("Falha na conexão com o banco de dados: " . $conn->connect_error);
            }

            // Consulta as bebidas no banco de dados
            $sql = "SELECT * FROM bebidas";
            $result = $conn->query($sql);

            if ($result->num_rows > 0):
                while ($row = $result->fetch_assoc()):
            ?>
                    <div class="bebida-card">
                        
                        <div class="bebida-content">
                            <h3 class="bebida-title"><?= htmlspecialchars($row['nome']) ?></h3>
                            <img src="<?= htmlspecialchars($row['imagem']) ?>" alt="<?= htmlspecialchars($row['nome']) ?>">
                            <p class="bebida-description"><?= nl2br(htmlspecialchars($row['descricao'])) ?></p>
                            <hr>
                        </div>
                    </div>
            <?php
                endwhile;
            else:
            ?>
                <p style="text-align: center;">Nenhuma bebida cadastrada ainda. Adicione bebidas no banco de dados para exibi-las aqui.</p>
            <?php
            endif;

            $conn->close();
            ?>
        </div>
    </div>
</body>
</html>
