<?php
// Configuração da chave de API da The Guardian
$api_key = 'c9b4735d-a4c8-4397-b9d2-87d9d2542a2e'; // Substitua pela sua chave de API
$query = 'gastronomy'; // Palavra-chave para buscar notícias relacionadas à gastronomia
$api_url = "https://content.guardianapis.com/search?q={$query}&api-key={$api_key}&show-fields=thumbnail,headline,trailText,short-url";

$response = file_get_contents($api_url);
if ($response === false) {
    echo "<p>Não foi possível carregar as notícias. Tente novamente mais tarde.</p>";
    exit;
}

// Converte a resposta JSON para um array PHP
$data = json_decode($response, true);
$articles = $data['response']['results'] ?? [];
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notícias de Gastronomia</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #FA9854, #FAB95C);
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .news-header {
            text-align: center;
            color: #FA622D;
            margin-bottom: 30px;
        }
        .news-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }
        .news-card {
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .news-card img {
            width: 100%;
            height: auto;
        }
        .news-content {
            padding: 15px;
        }
        .news-title {
            font-size: 18px;
            margin-bottom: 10px;
            color: #333;
        }
        .news-title a {
            text-decoration: none;
            color: #FA622D;
        }
        .news-description {
            font-size: 14px;
            color: #555;
        }
        .news-footer {
            text-align: right;
            margin-top: 10px;
        }
        .news-footer a {
            text-decoration: none;
            font-size: 12px;
            color: #FA622D;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="news-header">Notícias de Gastronomia</h1>
        <?php if (!empty($articles)): ?>
            <div class="news-grid">
                <?php foreach ($articles as $article): ?>
                    <div class="news-card">
                        <?php if (!empty($article['fields']['thumbnail'])): ?>
                            <img src="<?= $article['fields']['thumbnail'] ?>" alt="Imagem da notícia">
                        <?php endif; ?>
                        <div class="news-content">
                            <h3 class="news-title">
                                <a href="<?= $article['webUrl'] ?>" target="_blank">
                                    <?= $article['webTitle'] ?>
                                </a>
                            </h3>
                            <p class="news-description"><?= $article['fields']['trailText'] ?? 'Descrição não disponível.' ?></p>
                            <div class="news-footer">
                                <a href="<?= $article['webUrl'] ?>" target="_blank">Leia mais</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p>Não há notícias disponíveis no momento.</p>
        <?php endif; ?>
    </div>
</body>
</html>
