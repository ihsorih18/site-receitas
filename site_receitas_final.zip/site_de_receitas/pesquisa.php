<?php
// Conexão com o banco de dados receitas_exclusivas
$host = "localhost";
$user = "root";
$password = "";
$database = "receitas_exclusivas";

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Falha na conexão com o banco de dados: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Resultados da Pesquisa</title>
    <style>
        /* Estilo da página de pesquisa para harmonizar com a principal */

        /* Centraliza e estiliza o contêiner dos resultados */
        .search-results-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            text-align: center;
        }

        h1 {
            font-size: 28px;
            color: #333;
            margin-bottom: 20px;
        }

        /* Lista dos resultados */
        .results-list {
            list-style-type: none;
            padding: 0;
        }

        /* Cada item de resultado */
        .results-list li {
            margin: 15px 0;
            padding: 15px;
            border-radius: 8px;
            background-color: #f4f4f4;
            transition: background-color 0.3s ease;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        /* Link do título da receita */
        .results-list li a {
            text-decoration: none;
            color: #333;
            font-size: 20px;
            font-weight: bold;
            display: block;
        }

        /* Efeito ao passar o mouse */
        .results-list li:hover {
            background-color: #e0e0e0;
        }

        /* Mensagem de erro caso não encontre receitas */
        .no-results {
            color: #666;
            font-size: 18px;
        }

        body {
            background: linear-gradient(to right, #FA7C5C, #A8593E);
            font-family:Arial, Helvetica, sans-serif;
            
        }
    </style>
</head>
<body>
    <div class="search-results-container">
        <h1>Resultados da Pesquisa</h1>

        <?php
        // Recebe o termo de pesquisa do formulário
        if (isset($_GET['termo'])) {
            $termo = trim($_GET['termo']); // Remove espaços extras

            // Consulta para buscar receitas que contenham o termo no título
            $sql = "SELECT * FROM receitas WHERE nome LIKE ?";
            $stmt = $conn->prepare($sql);
            $likeTerm = '%' . $termo . '%';
            $stmt->bind_param("s", $likeTerm);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                echo "<ul class='results-list'>";
                // Exibe cada receita encontrada
                while ($row = $result->fetch_assoc()) {
                    echo "<li>";
                    echo "<h2>" . htmlspecialchars($row['nome']) . "</h2>";
                    echo "<img src='" . htmlspecialchars($row['imagem']) . "' alt='" . htmlspecialchars($row['nome']) . "' style='width:200px; height:200px; object-fit:cover; margin-top:15px;'>";
                    echo "<p><strong>Descrição:</strong> " . htmlspecialchars($row['descricao']) . "</p>";
                    echo "<p><strong>Ingredientes:</strong> " . nl2br(htmlspecialchars($row['ingredientes'])) . "</p>";
                    echo "<p><strong>Modo de Preparo:</strong> " . nl2br(htmlspecialchars($row['modo_preparo'])) . "</p>";
                    
                    echo "</li>";
                }
                echo "</ul>";
            } else {
                echo "<p class='no-results'>Nenhuma receita encontrada para o termo '" . htmlspecialchars($termo) . "'.</p>";
            }

            $stmt->close();
        } else {
            echo "<p class='no-results'>Por favor, digite um termo de pesquisa.</p>";
        }

        $conn->close();
        ?>
    </div>
</body>
</html>
