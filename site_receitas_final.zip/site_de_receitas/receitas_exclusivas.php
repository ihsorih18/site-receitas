<?php include 'db_connection.php'; ?>

<?php
// Conexão com o banco de dados receitas_exclusivas
$host = "localhost";
$user = "root";
$password = "";
$database = "receitas_exclusivas";

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Falha na conexão com o banco de dados: " . $conn->connect_error);
}

// Número de receitas por página
$receitas_por_pagina = 2;

// Página atual (padrão: 1)
$pagina_atual = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($pagina_atual - 1) * $receitas_por_pagina;

// Consulta para contar o número total de receitas
$sql_contagem = "SELECT COUNT(*) AS total FROM receitas";
$result_contagem = $conn->query($sql_contagem);
$total_receitas = $result_contagem->fetch_assoc()['total'];

// Calcula o número total de páginas
$total_paginas = ceil($total_receitas / $receitas_por_pagina);

// Consulta para buscar as receitas da página atual
$sql = "SELECT * FROM receitas LIMIT $offset, $receitas_por_pagina";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receitas Exclusivas</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #FA9854, #FAB95C);
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #FA622D;
            margin-bottom: 30px;
        }
        .receitas-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }
        .receita-card {
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .receita-card img {
            max-width: 150px; /* Tamanho reduzido da imagem */
            width: 100%;
            height: auto;
            object-fit: cover;
            display: block;
            margin: 0 auto;
        }
        .receita-content {
            padding: 15px;
        }
        .receita-title {
            font-size: 18px;
            margin-bottom: 10px;
            color: #333;
            text-align: center;
        }
        .receita-description {
            font-size: 14px;
            color: #555;
            text-align: justify;
        }
        .receita-details {
            margin-top: 10px;
            font-size: 14px;
            color: #666;
        }
        .receita-details strong {
            color: #333;
        }
        .pagination {
            text-align: center;
            margin-top: 20px;
        }
        .pagination a {
            display: inline-block;
            margin: 0 5px;
            padding: 10px 15px;
            background: #FA622D;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .pagination a:hover {
            background: #FAB95C;
        }
        .pagination .active {
            background: #333;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Receitas Exclusivas</h1>
    <div class="receitas-grid">
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="receita-card">
                    <div class="receita-content">
                        <h3 class="receita-title"><?= htmlspecialchars($row['nome']) ?></h3>
                    </div>
                    <img src="<?= htmlspecialchars($row['imagem']) ?>" alt="<?= htmlspecialchars($row['nome']) ?>">
                    <div class="receita-content">
                        <p class="receita-description"><?= htmlspecialchars($row['descricao']) ?></p>
                        <div class="receita-details">
                            <p><strong>Ingredientes:</strong> <?= nl2br(htmlspecialchars($row['ingredientes'])) ?></p>
                            <p><strong>Modo de Preparo:</strong> <?= nl2br(htmlspecialchars($row['modo_preparo'])) ?></p>
                            <hr>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p style="text-align: center;">Nenhuma receita encontrada. Adicione receitas no banco de dados para exibi-las aqui.</p>
        <?php endif; ?>
    </div>

    <!-- Paginação -->
    <div class="pagination">
        <?php if ($pagina_atual > 1): ?>
            <a href="?page=<?= $pagina_atual - 1 ?>">Anterior</a>
        <?php endif; ?>

        <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
            <a href="?page=<?= $i ?>" class="<?= $i === $pagina_atual ? 'active' : '' ?>"><?= $i ?></a>
        <?php endfor; ?>

        <?php if ($pagina_atual < $total_paginas): ?>
            <a href="?page=<?= $pagina_atual + 1 ?>">Próximo</a>
        <?php endif; ?>
    </div>
</div>

</body>
</html>

<?php
$conn->close();
?>
